<?php
    //mendefinisikan variabel
    $nama = "Lira";
    $umur = 18;
    $bb = 42;

    echo "Nama saya adalah :" .$nama;
    echo "<br/> umur :" .$umur. "tahun";
    echo "<br/> berat badan :" .$bb. "kg";
    
?>